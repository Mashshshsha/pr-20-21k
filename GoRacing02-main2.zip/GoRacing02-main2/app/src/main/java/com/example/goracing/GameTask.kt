package com.example.goracing

interface GameTask
{
    fun closeGame(mScore:Int)
}